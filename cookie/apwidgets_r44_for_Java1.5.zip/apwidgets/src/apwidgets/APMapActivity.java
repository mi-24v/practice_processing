package apwidgets;

import processing.core.PApplet;
import android.view.ViewGroup;

import com.google.android.maps.MapView;

public class APMapActivity{
	public void PMapActivity(){
		
		
	}
}
