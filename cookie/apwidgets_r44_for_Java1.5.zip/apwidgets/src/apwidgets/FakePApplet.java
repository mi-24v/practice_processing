package apwidgets;

public abstract class FakePApplet {
	
	public abstract void draw();
	public abstract void setup();
}
